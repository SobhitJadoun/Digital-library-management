Hey, My self Sobhit jadoun and I am here to show you a beautifull and most advanced project on Library Management, name is Book Storm,


Some step to setup our project first Extract zip file and Go to LMS folder here all files are available of our project.
now open your xampp server and start apache server and mysql,
then click on admin button and now open phpmyadmin page,
now create a new database name is lms
and import db.sql file inside  lms/databse folder then click go button
database setup automatically are setup