<?php include 'includes/header.php';
include 'includes/herosec.php'; 
include 'includes/aboutsec.php';
include 'includes/servicessec.php';
include 'includes/booksec.php';
include 'includes/team.php'; 
include 'includes/contactform.php';
include 'includes/footer.php';
 ?>