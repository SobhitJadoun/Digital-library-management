<?php
require('db.php');
include("auth_session.php");
?>