<?php include("includes/header.php"); 
include("includes/aboutsec.php")
?>
<style>
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  
  padding: 0 10px;
  margin-bottom:25px;
  
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  height:15rem;
  text-align: center;
  background-color: #e0e0d1;
}
</style>


<div class="row">
  <div class="column">
    <div class="card">
    <i class="bi bi-book"></i>
      <h3>Magzine</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h3>Ebook</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h3>News Paper</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h3>Novels</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>
</div>

<div class="row">
  <div class="column">
    <div class="card">
      <h3>Marketing Books</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h3>Compitative Books</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h3>General Knowledge Books</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h3>Motivational Book</h3>
      <p>Some text</p>
      <p>Some text</p>
    </div>
  </div>
</div>



<?php include ("includes/footer.php")?>