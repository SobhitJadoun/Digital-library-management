<!-- ======= book Section ======= -->
<section id="portfolio" class="portfolio">
  <div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2>Library</h2>
      <p>Check out our beautifull Books</p>
    </div>

    <div class="row" data-aos="fade-up" data-aos-delay="100">
      <div class="col-lg-12">
        <ul id="portfolio-flters">
          <li data-filter="*" class="filter-active">All</li>
          <li data-filter=".filter-app">EBook</li>
          <li data-filter=".filter-card">Audio Book</li>
          <li data-filter=".filter-web">Magzines</li>
        </ul>
      </div>
    </div>

    <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

      <div class="col-lg-4 col-md-6 portfolio-item filter-app">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/1.png" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/1.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="EBook"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>EBook</h4>
            <p>EBook</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-web">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/6.png" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/6.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Magazine"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>Magazine</h4>
            <p>Magazine</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-app">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/2.png" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/2.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="EBook 2"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>EBook 2</h4>
            <p>EBook</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-card">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/4.png" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/4.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Audio"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>Audio</h4>
            <p>Audio Book</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-web">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/3.png" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/3.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Magazine 2"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>Magazine 2</h4>
            <p>Web</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-app">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/5.jpg" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/5.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="EBook 3"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>EBook 3</h4>
            <p>EBook</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-card">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/9.jpg" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/9.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 1"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>Audio</h4>
            <p>Audio</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-card">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/10.jpg" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/10.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 3"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>Card 3</h4>
            <p>Card</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 portfolio-item filter-web">
        <div class="portfolio-wrap">
          <img src="assets/img/portfolio/11.jpg" class="img-fluid" alt="">
          <div class="portfolio-links">
            <a href="assets/img/portfolio/11.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bi bi-plus"></i></a>
            <a href="portfolio-details.html" title="More Details"><i class="bi bi-link"></i></a>
          </div>
          <div class="portfolio-info">
            <h4>Web 3</h4>
            <p>Web</p>
          </div>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Portfolio Section -->