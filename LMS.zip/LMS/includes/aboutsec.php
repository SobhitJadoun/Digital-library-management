<main id="main">
<!-- ======= About Section ======= -->
<section id="about" class="about">
  <div class="container">

    <div class="row justify-content-between">
      <div class="col-lg-5 d-flex align-items-center justify-content-center about-img">
        <img src="assets/img/about-img.svg" class="img-fluid" alt="" data-aos="zoom-in">
      </div>
      <div class="col-lg-6 pt-5 pt-lg-0">
        <h3 data-aos="fade-up">Book Storm Provide for you</h3>
        <p data-aos="fade-up" data-aos-delay="100">
          We work with publishers to build a quality-controlled collection of open access 
          books and provide services for publishers, libraries, and research funders in the
           areas of hosting, deposit, quality assurance, dissemination, and digital preservation.
        </p>
        <div class="row">
          <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
            <i class="bx bx-receipt"></i>
            <h4>Online study resources</h4>
            <p>Empower yourself with books, journals and eBooks from trusted publishers
               in all academic subject areas, along with powerful research tools.</p>
          </div>
          <div class="col-md-6" data-aos="fade-up" data-aos-delay="200">
            <i class="bx bx-cube-alt"></i>
            <h4>Read a magazine or newspaper</h4>
            <p>Stay updated with the world’s largest newsstand on your mobile device, with 
              instant access to nearly 6,000 newspapers and magazines from over 100 countries.</p>
          </div>
        </div>
      </div>
    </div>

  </div>
</section><!-- End About Section -->
