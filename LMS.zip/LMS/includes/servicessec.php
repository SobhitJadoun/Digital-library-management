<!-- ======= Services Section ======= -->
<section id="services" class="services section-bg">
  <div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2>Services</h2>
      <p>Check out the great services we offer</p>
    </div>

    <div class="row">
      <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
        <div class="icon-box">
          <div class="icon"><i class="bi bi-book"></i></div>
          <h4 class="title"><a href="">EBooks</a></h4>
          <p class="description">Explore Our best collection of Books, you can get free ebook and download 
            your favorite book in our site and you also can share. your ebook we will publish it for poor people to read and download for free.</p>
        </div>
      </div>

      <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="200">
        <div class="icon-box">
          <div class="icon"><i class="bx bx-file"></i></div>
          <h4 class="title"><a href="">Audio Book</a></h4>
          <p class="description">Download hundreds of free audio books, mostly classics, to your MP3 player or computer. Below, you’ll
             find great works of fiction, poetry and non-fiction, by such as  HG Wells & more. Also please see our related collection: The 150 Best Podcasts to Enrich Your Mind.</p>
        </div>
      </div>

      <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="300">
        <div class="icon-box">
          <div class="icon"><i class="bi bi-easel2-fill"></i></div>
          <h4 class="title"><a href="">Comics and graphic novels</a></h4>
          <p class="description">Get your kids unlimited access to more than 2,500 digital comics and graphic novels - from Ultraheroes, Starwars to Disney comics and more.</p>
        </div>
      </div>

      <div class="col-md-6 col-lg-3 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
        <div class="icon-box">
          <div class="icon"><i class="bx bx-world"></i></div>
          <h4 class="title"><a href="">Read a magazine or newspaper</a></h4>
          <p class="description">Stay updated with the world’s largest newsstand on your mobile device, with instant access to nearly 6,000 newspapers and magazines from over 100 countries</p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Services Section -->